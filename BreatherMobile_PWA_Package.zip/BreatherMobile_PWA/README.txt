BREATHERMOBILE AI — INSTALLABLE WEB APP PACKAGE

Files:
- index.html: main app
- manifest.json: app name, icon, and install settings
- service-worker.js: offline caching for the app shell
- icons/: app icons

IMPORTANT:
1. Keep these files together in the same folder.
2. An installable web app must be served from HTTPS (or localhost). Opening index.html directly as a file will not enable installation.
3. Upload the contents of this folder to a static HTTPS host. Once hosted, open the HTTPS link on your Android phone in Chrome.
4. In Chrome, open the menu (three dots) and choose "Install app" or "Add to Home screen" if offered.
5. App data is stored locally in each browser/device. This package does not sync data between phone and laptop.
6. The built-in assistant is a local helper, not a live AI connection.

Do not upload private business data as part of this package. Back up app data using Settings inside the app.
